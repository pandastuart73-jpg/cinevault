import { useSearchParams } from 'react-router-dom';
import { Typography } from '@mui/material';
import { normalise, useTmdb } from '../api';
import MovieList from '../components/MovieList';
import Status from '../components/Status';

export default function SearchResults() {
  const [params] = useSearchParams();
  const q = params.get('q') || '';
  const { data, loading, error } = useTmdb('/search/multi', { query: q });
  const items = (data?.results || []).filter((r) => r.media_type === 'movie' || r.media_type === 'tv').map((r) => normalise(r));

  return (
    <>
      <Typography variant="h4" sx={{ mb: 2 }}>Results for “{q}”</Typography>
      <Status loading={loading} error={error} empty={!items.length} emptyText={`No matches for “${q}”. Try a different title.`}>
        <MovieList items={items} />
      </Status>
    </>
  );
}
