import { Box } from '@mui/material';
import Section from '../components/Section';

export default function Home() {
  return (
    <Box>
      <Section title="Trending this week" path="/trending/all/week" />
      <Section title="Popular movies" path="/movie/popular" type="movie" />
      <Section title="Action movies" path="/discover/movie" params={{ with_genres: 28, sort_by: 'popularity.desc' }} type="movie" />
      <Section title="Popular TV shows" path="/tv/popular" type="tv" />
    </Box>
  );
}
