import { useState } from 'react';
import { Box, Chip, Pagination, Typography } from '@mui/material';
import { normalise, useTmdb } from '../api';
import MovieList from '../components/MovieList';
import Status from '../components/Status';

// One page used for both Movies (type="movie") and TV Shows (type="tv").
export default function Browse({ type }) {
  const [genre, setGenre] = useState(null);
  const [page, setPage] = useState(1);
  const genres = useTmdb(`/genre/${type}/list`);
  const { data, loading, error } = useTmdb(`/discover/${type}`, {
    sort_by: 'popularity.desc', page, ...(genre && { with_genres: genre }),
  });
  const items = (data?.results || []).map((r) => normalise(r, type));

  const pick = (id) => { setGenre(id); setPage(1); };

  return (
    <Box>
      <Typography variant="h4" sx={{ mb: 2 }}>{type === 'movie' ? 'Movies' : 'TV shows'}</Typography>
      <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 3 }}>
        <Chip label="All" color={genre ? 'default' : 'primary'} onClick={() => pick(null)} />
        {(genres.data?.genres || []).map((g) => (
          <Chip key={g.id} label={g.name} color={genre === g.id ? 'primary' : 'default'} onClick={() => pick(g.id)} />
        ))}
      </Box>
      <Status loading={loading} error={error} empty={!items.length} emptyText="No titles found for this genre.">
        <MovieList items={items} />
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <Pagination page={page} count={Math.min(data?.total_pages || 1, 500)} onChange={(_, p) => { setPage(p); window.scrollTo(0, 0); }}
            siblingCount={0} />
        </Box>
      </Status>
    </Box>
  );
}
