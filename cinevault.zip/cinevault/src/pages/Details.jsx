import { useNavigate, useParams } from 'react-router-dom';
import { Box, Button, Chip, Typography } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import StarIcon from '@mui/icons-material/Star';
import { img, normalise, useTmdb } from '../api';
import { useWatchlist } from '../WatchlistContext';
import Status from '../components/Status';

export default function Details() {
  const { type, id } = useParams();
  const navigate = useNavigate();
  const { has, toggle } = useWatchlist();
  const { data, loading, error } = useTmdb(`/${type}/${id}`);
  const item = data && normalise(data, type);
  const poster = data && img(data.poster_path, 'w500');
  const runtime = data?.runtime ? `${data.runtime} min` : data?.number_of_seasons ? `${data.number_of_seasons} season(s)` : null;

  return (
    <Box>
      <Button startIcon={<ArrowBackIcon />} onClick={() => navigate(-1)} sx={{ mb: 2 }}>Back</Button>
      <Status loading={loading} error={error}>
        {data && (
          <Box sx={{ display: 'flex', gap: 4, flexDirection: { xs: 'column', sm: 'row' } }}>
            <Box sx={{ flex: '0 0 auto', width: { xs: '60%', sm: 280 }, alignSelf: { xs: 'center', sm: 'flex-start' } }}>
              {poster
                ? <Box component="img" src={poster} alt={item.title} sx={{ width: '100%', borderRadius: 2 }} />
                : <Box sx={{ aspectRatio: '2/3', display: 'grid', placeItems: 'center', bgcolor: '#26211c', borderRadius: 2 }}>No poster</Box>}
            </Box>
            <Box>
              <Typography variant="h3" sx={{ fontSize: { xs: '1.8rem', md: '2.6rem' } }}>{item.title}</Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, my: 1.5, color: 'text.secondary', flexWrap: 'wrap' }}>
                <span>{data.release_date || data.first_air_date || 'Release date unknown'}</span>
                {runtime && <span>{runtime}</span>}
                <Box sx={{ display: 'flex', alignItems: 'center', gap: .5 }}>
                  <StarIcon sx={{ color: 'primary.main' }} fontSize="small" />
                  {item.rating ? `${item.rating} / 10` : 'Not rated'}
                </Box>
              </Box>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }}>
                {(data.genres || []).map((g) => <Chip key={g.id} label={g.name} variant="outlined" />)}
              </Box>
              <Typography sx={{ maxWidth: 640, mb: 3, lineHeight: 1.7 }}>{data.overview || 'No overview is available for this title.'}</Typography>
              <Button variant={has(item) ? 'outlined' : 'contained'} onClick={() => toggle(item)}>
                {has(item) ? 'Remove from watchlist' : 'Add to watchlist'}
              </Button>
            </Box>
          </Box>
        )}
      </Status>
    </Box>
  );
}
