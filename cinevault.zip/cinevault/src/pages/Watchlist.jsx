import { Typography } from '@mui/material';
import { useWatchlist } from '../WatchlistContext';
import MovieList from '../components/MovieList';
import Status from '../components/Status';

export default function Watchlist() {
  const { items } = useWatchlist();
  return (
    <>
      <Typography variant="h4" sx={{ mb: 2 }}>My watchlist</Typography>
      <Status empty={!items.length} emptyText="Your watchlist is empty. Tap the bookmark on any poster to save it here.">
        <MovieList items={items} />
      </Status>
    </>
  );
}
