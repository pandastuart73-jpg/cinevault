import { useEffect, useState } from 'react';

const KEY = import.meta.env.VITE_TMDB_API_KEY;
const BASE = 'https://api.themoviedb.org/3';

export const img = (path, size = 'w342') =>
  path ? `https://image.tmdb.org/t/p/${size}${path}` : null;

export async function tmdb(path, params = {}) {
  if (!KEY) throw new Error('Missing VITE_TMDB_API_KEY. Add it to your .env file (see README).');
  const qs = new URLSearchParams({ api_key: KEY, language: 'en-US', ...params });
  const res = await fetch(`${BASE}${path}?${qs}`);
  if (!res.ok) throw new Error(`Request failed (${res.status}). Check your API key and connection.`);
  return res.json();
}

// Normalise movie/TV objects so components don't care which one they got.
export function normalise(item, fallbackType) {
  const type = item.media_type || fallbackType;
  const date = item.release_date || item.first_air_date || '';
  return {
    id: item.id,
    type,
    title: item.title || item.name || 'Untitled',
    poster: item.poster_path || null,
    year: date ? date.slice(0, 4) : 'N/A',
    rating: item.vote_average ? Number(item.vote_average.toFixed(1)) : null,
  };
}

// Fetch hook: { data, loading, error } for a path + params.
export function useTmdb(path, params) {
  const [state, setState] = useState({ data: null, loading: true, error: null });
  const key = path + JSON.stringify(params || {});
  useEffect(() => {
    let cancelled = false;
    setState({ data: null, loading: true, error: null });
    tmdb(path, params)
      .then((data) => !cancelled && setState({ data, loading: false, error: null }))
      .catch((e) => !cancelled && setState({ data: null, loading: false, error: e.message }));
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  return state;
}
