import { createContext, useContext, useEffect, useState } from 'react';

const Ctx = createContext(null);
const STORAGE_KEY = 'cinevault-watchlist';

function load() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
  catch { return []; }
}

export function WatchlistProvider({ children }) {
  const [items, setItems] = useState(load);
  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); }, [items]);

  const has = (item) => items.some((i) => i.id === item.id && i.type === item.type);
  const toggle = (item) =>
    setItems((prev) =>
      has(item) ? prev.filter((i) => !(i.id === item.id && i.type === item.type)) : [...prev, item]
    );

  return <Ctx.Provider value={{ items, has, toggle }}>{children}</Ctx.Provider>;
}
export const useWatchlist = () => useContext(Ctx);
