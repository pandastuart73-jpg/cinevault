import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Browse from './pages/Browse';
import SearchResults from './pages/SearchResults';
import Details from './pages/Details';
import Watchlist from './pages/Watchlist';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="movies" element={<Browse key="movie" type="movie" />} />
        <Route path="tv" element={<Browse key="tv" type="tv" />} />
        <Route path="search" element={<SearchResults />} />
        <Route path="watchlist" element={<Watchlist />} />
        <Route path=":type/:id" element={<Details />} />
        <Route path="*" element={<p>Page not found.</p>} />
      </Route>
    </Routes>
  );
}
