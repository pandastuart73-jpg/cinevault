import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { CssBaseline, ThemeProvider, createTheme } from '@mui/material';
import App from './App';
import { WatchlistProvider } from './WatchlistContext';

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: { main: '#f0a500' },
    background: { default: '#16120f', paper: '#211b16' },
  },
  shape: { borderRadius: 8 },
  typography: { fontFamily: '"Trebuchet MS", "Segoe UI", system-ui, sans-serif', h4: { fontWeight: 700 }, h5: { fontWeight: 700 } },
});

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <WatchlistProvider><App /></WatchlistProvider>
      </BrowserRouter>
    </ThemeProvider>
  </React.StrictMode>
);
