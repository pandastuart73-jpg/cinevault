import { Link } from 'react-router-dom';
import { Box, Card, CardActionArea, CardContent, IconButton, Typography } from '@mui/material';
import StarIcon from '@mui/icons-material/Star';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import BookmarkBorderIcon from '@mui/icons-material/BookmarkBorder';
import { img } from '../api';
import { useWatchlist } from '../WatchlistContext';

export default function MovieCard({ item }) {
  const { has, toggle } = useWatchlist();
  const saved = has(item);
  const src = img(item.poster);

  return (
    <Card sx={{ position: 'relative', bgcolor: 'background.paper', transition: 'transform .2s, box-shadow .2s',
      '&:hover': { transform: 'translateY(-4px)', boxShadow: '0 8px 24px rgba(0,0,0,.6)' } }}>
      <CardActionArea component={Link} to={`/${item.type}/${item.id}`}>
        {src ? (
          <Box component="img" src={src} alt={item.title} loading="lazy"
            sx={{ width: '100%', aspectRatio: '2/3', objectFit: 'cover', display: 'block' }} />
        ) : (
          <Box sx={{ aspectRatio: '2/3', display: 'grid', placeItems: 'center', bgcolor: '#26211c', p: 1 }}>
            <Typography variant="body2" color="text.secondary" align="center">No poster</Typography>
          </Box>
        )}
        <CardContent sx={{ p: 1.25 }}>
          <Typography variant="body2" fontWeight={600} noWrap title={item.title}>{item.title}</Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, color: 'text.secondary' }}>
            <Typography variant="caption">{item.year}</Typography>
            {item.rating && (<><StarIcon sx={{ fontSize: 14, color: 'primary.main', ml: 'auto' }} />
              <Typography variant="caption">{item.rating}</Typography></>)}
          </Box>
        </CardContent>
      </CardActionArea>
      <IconButton size="small" onClick={() => toggle(item)}
        aria-label={saved ? 'Remove from watchlist' : 'Add to watchlist'}
        sx={{ position: 'absolute', top: 6, right: 6, bgcolor: 'rgba(0,0,0,.65)', '&:hover': { bgcolor: 'rgba(0,0,0,.85)' } }}>
        {saved ? <BookmarkIcon color="primary" /> : <BookmarkBorderIcon />}
      </IconButton>
    </Card>
  );
}
