import { Box } from '@mui/material';
import MovieCard from './MovieCard';

// Responsive poster grid: 2 columns on phones, more as space allows.
export default function MovieList({ items }) {
  return (
    <Box sx={{ display: 'grid', gap: 2,
      gridTemplateColumns: { xs: 'repeat(2, 1fr)', sm: 'repeat(auto-fill, minmax(150px, 1fr))' } }}>
      {items.map((it) => <MovieCard key={`${it.type}-${it.id}`} item={it} />)}
    </Box>
  );
}
