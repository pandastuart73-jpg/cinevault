import { Alert, Box, CircularProgress, Typography } from '@mui/material';

// Shows loading / error / empty states; renders children otherwise.
export default function Status({ loading, error, empty, emptyText = 'Nothing to show here yet.', children }) {
  if (loading) return <Box sx={{ py: 6, textAlign: 'center' }}><CircularProgress color="primary" aria-label="Loading" /></Box>;
  if (error) return <Alert severity="error" sx={{ my: 2 }}>{error}</Alert>;
  if (empty) return <Typography color="text.secondary" sx={{ py: 4 }}>{emptyText}</Typography>;
  return children;
}
