import { Box, Typography } from '@mui/material';
import { normalise, useTmdb } from '../api';
import MovieCard from './MovieCard';
import Status from './Status';

// A titled, horizontally scrolling row of posters loaded from the API.
export default function Section({ title, path, params, type }) {
  const { data, loading, error } = useTmdb(path, params);
  const items = (data?.results || []).filter((r) => !r.media_type || r.media_type !== 'person')
    .map((r) => normalise(r, type)).slice(0, 15);
  return (
    <Box component="section" sx={{ mb: 4 }}>
      <Typography variant="h5" sx={{ mb: 1.5 }}>{title}</Typography>
      <Status loading={loading} error={error} empty={!items.length}>
        <Box sx={{ display: 'flex', gap: 2, overflowX: 'auto', pb: 1, scrollSnapType: 'x proximity' }}>
          {items.map((it) => (
            <Box key={`${it.type}-${it.id}`} sx={{ flex: '0 0 auto', width: { xs: 130, sm: 160 }, scrollSnapAlign: 'start' }}>
              <MovieCard item={it} />
            </Box>
          ))}
        </Box>
      </Status>
    </Box>
  );
}
