import { useState } from 'react';
import { NavLink, Outlet, useNavigate, useSearchParams } from 'react-router-dom';
import { AppBar, Box, Divider, Drawer, IconButton, InputAdornment, List, ListItemButton, ListItemIcon,
  ListItemText, TextField, Toolbar, Typography, useMediaQuery } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import HomeIcon from '@mui/icons-material/Home';
import MovieIcon from '@mui/icons-material/Movie';
import TvIcon from '@mui/icons-material/Tv';
import BookmarkIcon from '@mui/icons-material/Bookmark';

const WIDTH = 220;
const links = [
  ['/', 'Home', <HomeIcon />],
  ['/movies', 'Movies', <MovieIcon />],
  ['/tv', 'TV Shows', <TvIcon />],
  ['/watchlist', 'My Watchlist', <BookmarkIcon />],
];

export default function Layout() {
  const theme = useTheme();
  const desktop = useMediaQuery(theme.breakpoints.up('md'));
  const [open, setOpen] = useState(false);
  const [params] = useSearchParams();
  const [q, setQ] = useState(params.get('q') || '');
  const navigate = useNavigate();

  const submit = (e) => {
    e.preventDefault();
    if (q.trim()) navigate(`/search?q=${encodeURIComponent(q.trim())}`);
  };

  const nav = (
    <Box sx={{ width: WIDTH, display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Toolbar />
      <List sx={{ px: 1 }}>
        {links.map(([to, label, icon]) => (
          <ListItemButton key={to} component={NavLink} to={to} end={to === '/'} onClick={() => setOpen(false)}
            sx={{ borderRadius: 1, '&.active': { bgcolor: 'rgba(240,165,0,.15)', color: 'primary.main', '& .MuiListItemIcon-root': { color: 'primary.main' } } }}>
            <ListItemIcon sx={{ minWidth: 38 }}>{icon}</ListItemIcon>
            <ListItemText primary={label} />
          </ListItemButton>
        ))}
      </List>
      <Box sx={{ mt: 'auto', p: 2 }}>
        <Divider sx={{ mb: 1 }} />
        <Typography variant="caption" color="text.secondary">
          This product uses the TMDB API but is not endorsed or certified by TMDB.
        </Typography>
      </Box>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex' }}>
      <AppBar position="fixed" color="default" elevation={0} sx={{ zIndex: (t) => t.zIndex.drawer + 1, bgcolor: 'background.paper', borderBottom: '1px solid #3a322a' }}>
        <Toolbar sx={{ gap: 1.5 }}>
          {!desktop && <IconButton edge="start" onClick={() => setOpen(true)} aria-label="Open menu"><MenuIcon /></IconButton>}
          <Typography component={NavLink} to="/" variant="h6" sx={{ color: 'primary.main', textDecoration: 'none', fontWeight: 800, letterSpacing: 1, mr: 1 }}>
            CINEVAULT
          </Typography>
          <Box component="form" onSubmit={submit} sx={{ flex: 1, maxWidth: 520, ml: 'auto', mr: { md: 'auto' } }}>
            <TextField fullWidth size="small" placeholder="Search movies & TV shows" value={q}
              onChange={(e) => setQ(e.target.value)} inputProps={{ 'aria-label': 'Search' }}
              InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment> }} />
          </Box>
        </Toolbar>
      </AppBar>

      <Drawer variant={desktop ? 'permanent' : 'temporary'} open={desktop || open} onClose={() => setOpen(false)}
        sx={{ width: desktop ? WIDTH : 0, '& .MuiDrawer-paper': { width: WIDTH, boxSizing: 'border-box', bgcolor: 'background.paper' } }}>
        {nav}
      </Drawer>

      <Box component="main" sx={{ flexGrow: 1, minWidth: 0, p: { xs: 2, md: 3 } }}>
        <Toolbar />
        <Outlet />
      </Box>
    </Box>
  );
}
